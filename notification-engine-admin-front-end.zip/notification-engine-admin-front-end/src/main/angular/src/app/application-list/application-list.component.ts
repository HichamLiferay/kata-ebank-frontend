import {Component, ViewChild} from '@angular/core';
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {MatTableDataSource} from "@angular/material/table";
import {Application} from "../shared/model/application.model";
import {MatDialog} from "@angular/material/dialog";
import {ApplicationService} from "../shared/services/application.service";
import {DialogService} from "../shared/services/dialog.service";
import {NotificationService} from "../shared/services/notifications.service";

@Component({
  selector: 'app-application-list',
  templateUrl: './application-list.component.html',
  styleUrls: ['./application-list.component.scss']
})
export class ApplicationListComponent {

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  displayedColumns: string[] = ['isSelected', 'applicationId', 'applicationName', 'emailFrom', 'actions'];
  dataSource = new MatTableDataSource<Application>();
  isApplicationAdded = false;
  originalRowCopy: Application | null = null;
  isLoadingData = false;

  constructor(
    public dialog: MatDialog,
    private applicationService: ApplicationService,
    private dialogService: DialogService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.loadData();
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  loadData() {
    this.isLoadingData = true; // Set loading state to true
    this.applicationService.getApplications().subscribe({
      next: (res: Application[]) => {
        this.dataSource.data = res;
        this.isLoadingData = false; // Set loading state to false when data is received
      },
      error: (error) => {
        this.isLoadingData = false;// Set loading state to false in case of an error
        this.notificationService.openSnackBar('An error occurred while loading applications.', 'error');
      }
    });
  }

  editRow(row: Application) {
    if (row.id === '') {
      this.applicationService
        .addApplication(row)
        .subscribe({
          next: (response) => {
            row.id = response.id;
            row.isEdit = false;
            this.isApplicationAdded = false;
            this.notificationService.openSnackBar('Application added successfully !','success');
          },
          error: (error) => {
            if (error && error.error && error.error.message) {
              const errorMessage = error.error.message;
              this.notificationService.openSnackBar(`Error while adding application: ${errorMessage}`, 'error');
            } else {
              this.notificationService.openSnackBar('An error occurred while adding application.', 'error');
            }
          }
        });
    } else {
      this.applicationService
        .updateApplication(row)
        .subscribe({
          next: (response) => {
            row.isEdit = false;
            this.notificationService.openSnackBar('Application updated successfully !', 'success');
          },
          error: (error) => {
            if (error && error.error && error.error.message) {
              const errorMessage = error.error.message;
              this.notificationService.openSnackBar(`Error while updating application: ${errorMessage}`, 'error');
            } else {
              this.notificationService.openSnackBar('An error occurred while updating application.', 'error');
            }
          }
        });
    }
  }

  toggleEditMode(row: Application) {
    this.originalRowCopy = {...row};
    row.isEdit = !row.isEdit;
  }

  addRow() {
    if (!this.isApplicationAdded) {
      this.isApplicationAdded = true;
      const newRow: Application = {
        id: '',
        applicationId: '',
        applicationName: '',
        emailFrom: '',
        isEdit: true,
        isSelected: false,
      };
      this.dataSource.data = [newRow, ...this.dataSource.data];
    }
  }

  cancelAddRow() {
    this.dataSource.data = this.dataSource.data.filter((row) => row.id !== '');
    this.isApplicationAdded = false;
  }

  cancelEditRow(row: Application) {
    row.isEdit = false;
    Object.assign(row, this.originalRowCopy);
  }

  removeRow(application: Application) {
    this.dialogService.openConfirmDialog('Are you sure to delete ' + application.applicationName + ' application ?')
      .afterClosed().subscribe(
      (confirm) => {
        if (confirm) {
          this.applicationService.deleteApplication(application.id).subscribe({
            next: (response) => {
              this.dataSource.data = this.dataSource.data.filter(
                (u: Application) => u.id !== application.id
              );
              this.notificationService.openSnackBar('Application Deleted successfully !', 'success');
            },
            error: (error) => {
              if (error && error.error && error.error.message) {
                const errorMessage = error.error.message;
                this.notificationService.openSnackBar(`Error while deleting application: ${errorMessage}`, 'error');
              } else {
                this.notificationService.openSnackBar('An error occurred while deleting application.', 'error');
              }
            }
          });
        }
      }
    );
  }

  removeSelectedRows() {
    const applications = this.dataSource.data.filter(
      (u: Application) => u.isSelected
    );
    this.dialogService.openConfirmDialog('Are you sure to delete the selected applications ?')
      .afterClosed().subscribe((confirm) => {
      if (confirm) {
        this.applicationService
          .deleteApplications(applications)
          .subscribe({
            next: (response) => {
              this.dataSource.data = this.dataSource.data.filter(
                (u: Application) => !u.isSelected
              );
              this.notificationService.openSnackBar('Applications Deleted successfully !', 'success');
            },
            error: (error) => {
              if (error && error.error && error.error.message) {
                const errorMessage = error.error.message;
                this.notificationService.openSnackBar(`Error while deleting selected applications: ${errorMessage}`, 'error');
              } else {
                this.notificationService.openSnackBar('An error occurred while deleting selected applications.', 'error');
              }
            }
          });
      } else {
        this.dataSource.data.forEach((item) => {
          if (item.isSelected) {
            item.isSelected = false;
          }
        });
      }
    });
  }

  disableSubmit(row: Application) {
    const isApplicationNameEmpty = row.applicationName.trim() === '';
    const isApplicationIdEmpty = row.applicationId.trim() === '';
    const isEmailFromEmpty = row.emailFrom.trim() === '';
    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
      row.emailFrom.trim()
    );

    return (
      isApplicationNameEmpty ||
      isApplicationIdEmpty ||
      isEmailFromEmpty ||
      !isEmailValid
    );
  }

  isEditMode(): boolean {
    return this.dataSource.data.some((item) => item.isEdit);
  }

  isAllSelected() {
    return this.dataSource.data.length > 0 && this.dataSource.data.every((item) => item.isSelected);
  }

  isAnySelected() {
    return this.dataSource.data.some((item) => item.isSelected);
  }

  selectAll(event: any) {
    this.dataSource.data = this.dataSource.data.map((item) => ({
      ...item,
      isSelected: event.checked,
    }));
  }

  copyPublicKey(pubKey: string) {
    const copyButton = document.getElementById('copyButton');
    copyButton?.addEventListener('click', async () => {
      try {
        if (pubKey && pubKey !== "") await navigator.clipboard.writeText(pubKey);
      } catch (error) {
        this.notificationService.openSnackBar('Failed to copy to clipboard.', 'error');
      }
    });
  }

}
