import {environment} from "../../../environments/environment";

export class BackendUrl {

  public static MN_APPS_URL = environment.BASE_PATH + '/v1/config/applications/';
  public static MN_EVENTS_URL = environment.BASE_PATH + '/v1/config/events/';
}
