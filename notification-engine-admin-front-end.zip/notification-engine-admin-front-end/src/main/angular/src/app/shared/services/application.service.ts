import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Application } from '../model/application.model';
import {BackendUrl} from "../../common/enums/backend-url";

@Injectable({
  providedIn: 'root',
})
export class ApplicationService {

  constructor(private http: HttpClient) {}

  getApplications(): Observable<Application[]> {
    return this.http
      .get(BackendUrl.MN_APPS_URL)
      .pipe<Application[]>(map((data: any) => data));
  }

  addApplication(application: Application): Observable<Application> {
    return this.http.post<Application>(BackendUrl.MN_APPS_URL, application);
  }

  updateApplication(application: Application): Observable<Application> {
    return this.http.put<Application>(
      BackendUrl.MN_APPS_URL+`${application.id}`,
      application
    );
  }

  deleteApplication(id: string): Observable<Application> {
    return this.http.delete<Application>(BackendUrl.MN_APPS_URL+`${id}`);
  }

  deleteApplications(applications: Application[]) {

    return forkJoin(
      applications.map((application) =>
        this.http.delete<Application>(
          BackendUrl.MN_APPS_URL+`${application.id}`,
        )
      )
    );
  }
}
