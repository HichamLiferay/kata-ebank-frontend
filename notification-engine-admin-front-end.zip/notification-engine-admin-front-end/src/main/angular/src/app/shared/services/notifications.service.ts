import {Injectable, OnInit} from '@angular/core';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition
} from "@angular/material/snack-bar";


@Injectable({
  providedIn: 'root'
})
export class NotificationService implements OnInit {

  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';

  constructor(public snackBar: MatSnackBar) {
  }

  openSnackBar(msg: string, messageType: string) {

    const panelClass = messageType === 'success' ? ['success-snackbar'] : ['failed-snackbar'];

    const snackBarConfig = {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      panelClass: panelClass,
      data: {
        icon: 'error',
        message: msg
      }
    };

    let duration: number | undefined;

    if (messageType === 'success') {
      duration = 5000;
      this.snackBar.open(msg, '', {...snackBarConfig, duration});

    } else if (messageType === 'error') {
      this.snackBar.open(msg,'OK',snackBarConfig);
    }
  }

  ngOnInit(): void {}
}
