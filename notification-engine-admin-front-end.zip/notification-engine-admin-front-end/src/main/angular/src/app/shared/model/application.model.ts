export interface Application {
  isSelected: boolean;
  id: string;
  applicationName: string;
  applicationId: string;
  emailFrom: string;
  publicKey?: string;
  isEdit: boolean;
}
