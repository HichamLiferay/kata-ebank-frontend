export const environment = {
  production: false,
  BASE_PATH: 'http://localhost:8085/notification-engine'
}

