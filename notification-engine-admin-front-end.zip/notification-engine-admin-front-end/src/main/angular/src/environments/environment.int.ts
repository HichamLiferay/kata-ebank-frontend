export const environment = {
  production: true,
  BASE_PATH: 'https://mbank-dev.staging.bnpparibas.ma/notification-engine'
}
